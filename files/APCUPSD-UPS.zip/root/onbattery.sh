#!/bin/bash

date=$(date '+%Y-%m-%d %H:%M:%S')

curl -sSG "http://rpi.example.com/api/notification.php?token=yourpassword" --data-urlencode "title=UPS Status" --data-urlencode "message=UPS ALERT: Power failure detected, will shut down soon if ac power is not restored - $date"
# Your additional notification API goes here

echo "$date - ALERT: Power failure detected" >> /mnt/data/log/systemadmin.log

exit 0
