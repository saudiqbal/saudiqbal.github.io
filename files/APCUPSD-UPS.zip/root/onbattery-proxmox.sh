#!/bin/bash
PATH=/bin:/sbin:/usr/bin:/usr/sbin:/usr/local/bin:/usr/local/sbin:~/bin

sleep 180

date=$(date '+%Y-%m-%d %H:%M:%S')

upsstatus=$(apcaccess -p STATUS)

if [ $upsstatus == "ONBATT" ]; then
curl -sSG "http://rpi.example.com/api/notification.php?token=yourpassword" --data-urlencode "title=Proxmox Status" --data-urlencode "message=Proxmox shutdown initiated - $date"
# Your additional notification API goes here
curl -XPOST -H 'Authorization: PVEAPIToken=shutdown@pve!shutdown=xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxx' https://proxmox.example.com:8006/api2/json/nodes/nodename/status --data 'command=shutdown'
fi

exit 0
