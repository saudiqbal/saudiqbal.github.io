#!/usr/bin/bash

date=$(date '+%Y-%m-%d %H:%M:%S')

curl -sSG "http://rpi.example.com/api/notification.php?token=yourpassword" --data-urlencode "title=UPS ALERT" --data-urlencode "message=RPI-1 Booted - $date"
# Your additional notification API goes here

exit 0
