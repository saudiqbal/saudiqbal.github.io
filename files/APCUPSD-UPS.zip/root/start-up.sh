#!/usr/bin/bash

date=$(date '+%Y-%m-%d %H:%M:%S')

echo "$date - RPI-1 Booted" >> /mnt/data/log/systemadmin.log
curl -sSG "http://rpi.example.com/api/notification.php?token=yourpassword" --data-urlencode "title=UPS ALERT" --data-urlencode "message=RPI-1 Booted - $date"
# Your additional notification API goes here

exit 0
