#!/bin/bash

date=$(date '+%Y-%m-%d %H:%M:%S')
batterystatus=$(apcaccess -p BCHARGE | cut -f1 -d".")

function networkup {
  # Initialize number of attempts
  reachable=$1
  while [ $reachable -ne 0 ]; do
    # Ping supplied host
    ping -q -c 1 -W 1 "$2" > /dev/null 2>&1
    # Check return code
    if [ $? -eq 0 ]; then
      # Success, we can exit with the right return code
      echo 0
      return
    fi
    # Network down, decrement counter and try again
    upsstatus=$(apcaccess -p STATUS)
    if [ "$batterystatus" -ge 25 ] && [ $upsstatus == "ONLINE" ]; then
    curl -sSG "http://rpi.example.com/api/notification.php?token=yourpassword" --data-urlencode "title=Proxmox Status" --data-urlencode "message=Proxmox starting the server - $date"
    echo "$date - ALERT: Proxmox starting the server" >> /mnt/data/log/systemadmin.log
    # apt-get install wakeonlan
    MAC_ADDR="D1:AE:52:C9:D3:C2"
    WOL="/usr/bin/wakeonlan"
    $WOL "$MAC_ADDR"
    fi
    let reachable-=1
    # Sleep
    sleep 900
    batterystatus=$(apcaccess -p BCHARGE | cut -f1 -d".")
  done
  # Network down, number of attempts exhausted, quiting
  echo 1
}

# Start-up a web browser, if network is up
if [ $(networkup 25 proxmox.example.com) -eq 0 ]; then
echo "$date - ALERT: Proxmox server already up, skipping wake on lan" >> /mnt/data/log/systemadmin.log
curl -sSG "http://rpi.example.com/api/notification.php?token=yourpassword" --data-urlencode "title=Proxmox Status" --data-urlencode "message=Proxmox server already up, skipping wake on lan - $date"

fi

exit 0
