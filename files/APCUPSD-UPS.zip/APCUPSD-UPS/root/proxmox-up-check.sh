#!/bin/bash
PATH=/bin:/sbin:/usr/bin:/usr/sbin:/usr/local/bin:/usr/local/sbin:~/bin

TARGET="proxmox.example.com"
RETRYCOUNTER="12"
PINGSTATUS=$(ping -q -c 1 -W 1 $TARGET &> /dev/null && echo 0 || echo 1)
if [ $PINGSTATUS -eq 0 ]; then
	logger -t SystemAdmin -p warning "[System Admin] ALERT: Proxmox up check, $TARGET server already up, skipping wake on lan"
else
	# Wait time before sending WOL packet after the power comes back
	sleep 15m
	x=1
	while [ $PINGSTATUS -eq 1 ] && [ $x -le "$RETRYCOUNTER" ]
	do
		PINGSTATUS=$(ping -q -c 1 -W 1 $TARGET &> /dev/null && echo 0 || echo 1)
		logger -t SystemAdmin -p warning "[System Admin] Proxmox up check attempt: $x"
		batterystatus=$(apcaccess -p BCHARGE | cut -f1 -d".")
		upsstatus=$(apcaccess -p STATUS)
		if [ "$batterystatus" -ge 25 ] && [ $upsstatus == "ONLINE" ] && [ $PINGSTATUS -eq 1 ]; then
			# Your additional notification API calls
			# date=$(date '+%Y-%m-%d %H:%M:%S')
			# curl -sSG "http://rpi.example.com/api/notification.php?token=yourpassword" --data-urlencode "title=Proxmox Status" --data-urlencode "message=Proxmox up check, starting the server - $date"
			/usr/bin/wakeonlan D1:AE:52:C9:D3:C2
			logger -t SystemAdmin -p warning "[System Admin] ALERT: Proxmox up check, server offline, wake on lan packet sent to $TARGET"
		fi
		sleep 180
		PINGSTATUS=$(ping -q -c 1 -W 1 $TARGET &> /dev/null && echo 0 || echo 1)
		if [ $PINGSTATUS -eq 0 ]; then
		logger -t SystemAdmin -p warning "[System Admin] Proxmox up check, server is now online and verified, exiting"
		break
		fi
		x=$(( $x + 1 ))
	done
	if [ "$x" -gt "$RETRYCOUNTER" ]; then
	logger -t SystemAdmin -p warning "[System Admin] Proxmox up check script exhausted all attempts"
	fi
fi

exit 0
