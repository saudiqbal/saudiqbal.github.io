#!/bin/bash

date=$(date '+%Y-%m-%d %H:%M:%S')

#curl -sSG "http://rpi.example.com/api/notification.php?token=yourpassword" --data-urlencode "title=UPS Status" --data-urlencode "message=UPS ALERT: Power is restored - $date"
# Your additional notification API goes here


exit 0
