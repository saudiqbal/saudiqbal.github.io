#!/bin/bash
PATH=/bin:/sbin:/usr/bin:/usr/sbin:/usr/local/bin:/usr/local/sbin:~/bin

batterynotification75="0"
batterynotification50="0"
batterynotification05="0"

upsstatus=$(apcaccess -p STATUS)


while [ $upsstatus == "ONBATT" ]; do
batterystatus=$(apcaccess -p BCHARGE | cut -f1 -d".")
date=$(date '+%Y-%m-%d %H:%M:%S')

if [ "$batterystatus" -ge 51 ] && [ "$batterystatus" -le 75 ] && [ "$batterynotification75" != 1 ]; then
#curl -sSG "http://rpi.example.com/api/notification.php?token=yourpassword" --data-urlencode "title=UPS Status" --data-urlencode "message=UPS ALERT: Battery level is at 75% - $date"
# Your additional notification API goes here
batterynotification75="1"
elif [ "$batterystatus" -ge 6 ] && [ "$batterystatus" -le 50 ] && [ "$batterynotification50" != 1 ]; then
#curl -sSG "http://rpi.example.com/api/notification.php?token=yourpassword" --data-urlencode "title=UPS Status" --data-urlencode "message=UPS ALERT: Battery level is at 50% - $date"
# Your additional notification API goes here
batterynotification50="1"
elif [ "$batterystatus" -ge 0 ] && [ "$batterystatus" -le 5 ] && [ "$batterynotification05" != 1 ]; then
#curl -sSG "http://rpi.example.com/api/notification.php?token=yourpassword" --data-urlencode "title=UPS Status" --data-urlencode "message=UPS ALERT: Battery level is at 5% - $date"
# Your additional notification API goes here
batterynotification05="1"
fi
# Sleep
sleep 60
upsstatus=$(apcaccess -p STATUS)
done

exit 0
