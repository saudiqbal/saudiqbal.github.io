<?php
$startTime = array_sum(explode(' ', microtime()));
header("Cache-Control: no-store, must-revalidate");

// DISK USAGE
/* get disk space free (in bytes) */
//$df = disk_free_space("/");
$df = shell_exec('df -k | awk \'$1=="/dev/mmcblk0p2"{print $4}\'') * 1024;
/* and get disk space total (in bytes)  */
//$dt = disk_total_space("/");
$dt = shell_exec('df -k | awk \'$1=="/dev/mmcblk0p2"{print $2}\'') * 1024;
/* now we calculate the disk space used (in bytes) */
//$du = $dt - $df;
$du = shell_exec('df -k | awk \'$1=="/dev/mmcblk0p2"{print $3}\'') * 1024;
/* percentage of disk used - this will be used to also set the width % of the progress bar */
$dp = sprintf('%.2f',($du / $dt) * 100);

/* and we formate the size from bytes to MB, GB, etc. */
$df = formatSize($df);
$du = formatSize($du);
$dt = formatSize($dt);

function formatSize( $bytes )
{
$types = array( 'B', 'KB', 'MB', 'GB', 'TB' );
for( $i = 0; $bytes >= 1024 && $i < ( count( $types ) -1 ); $bytes /= 1024, $i++ );
return( round( $bytes, 2 ) . " " . $types[$i] );
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<title>Rpi-1 Server</title>
<meta name="viewport" content="user-scalable=yes, initial-scale=1, width=device-width">
<link rel="icon" href="data:;base64,iVBORw0KGgo=">
<link rel="stylesheet" type="text/css" href="/css/dashboard-header.css">
<script src="/js/keyboard-navigation.js"></script>
<script>
if(typeof(EventSource) !== "undefined")
{
var source = new EventSource("/php/notification-server-json.php");
source.onmessage = function(event) {
var data = JSON.parse(event.data);
document.getElementById("serverresponse").innerHTML = data.ramusage;
document.getElementById("ramtotal").innerHTML = data.ramtotal;

document.getElementById("rambar").innerHTML = drawPercentBar(200, data.rampercentage, '#4eaeff', '#cce9ff');
document.getElementById("cpubar").innerHTML = drawCPUBar(200, data.cpu, '#4eaeff', '#cce9ff');
};
} else {
document.getElementById("serverresponse").innerHTML = "Sorry, your browser does not support server-sent events...";
}
function setDISK() {
document.getElementById("diskbar").innerHTML = drawDISKBar(200, <?php echo $dp; ?>, '#4eaeff', '#cce9ff');
}
window.onload = setDISK;
</script>
<script language="javascript">
// drawPercentBar()
// Written by Matthew Harvey (matt AT unlikelywords DOT com)
// (http://www.unlikelywords.com/html-morsels/)
// Distributed under the Creative Commons
// "Attribution-NonCommercial-ShareAlike 2.0" License
// (http://creativecommons.org/licenses/by-nc-sa/2.0/)
function drawPercentBar(width, percent, color, background)
{
var pixels = width * (percent / 100);
if (!background) { background = "none"; }
if(percent>=50 && percent<=75)
{
color = "#ff8c00";
}
else if(percent>75 && percent<=100)
{
color = "#ff0000";
}
var htmlcode = "<div style=\"position: relative; line-height: 1em; background-color: " + background + "; border: 1px solid black; width: " + width + "px\">"
+ "<div style=\"height: 1.5em; width: " + pixels + "px; background-color: " + color + ";\"></div>"
+ "<div style=\"position: absolute; text-align: center; padding-top: .25em; width: " + width + "px; top: 0; left: 0\">" + percent + "%</div>"
+ "</div>";
return htmlcode;
}

function drawCPUBar(width, percent, color, background)
{
var pixels = width * (percent / 100);
if (!background) { background = "none"; }
if(percent>=50 && percent<=75)
{
color = "#ff8c00";
}
else if(percent>75 && percent<=100)
{
color = "#ff0000";
}
var cpucode = "<div style=\"position: relative; line-height: 1em; background-color: " + background + "; border: 1px solid black; width: " + width + "px\">"
+ "<div style=\"height: 1.5em; width: " + pixels + "px; background-color: " + color + ";\"></div>"
+ "<div style=\"position: absolute; text-align: center; padding-top: .25em; width: " + width + "px; top: 0; left: 0\">" + percent + "%</div>"
+ "</div>";
return cpucode;
}

function drawDISKBar(width, percent, color, background)
{
var pixels = width * (percent / 100);
if (!background) { background = "none"; }
if(percent>=50 && percent<=75)
{
color = "#ff8c00";
}
else if(percent>75 && percent<=100)
{
color = "#ff0000";
}
var diskcode = "<div style=\"position: relative; line-height: 1em; background-color: " + background + "; border: 1px solid black; width: " + width + "px\">"
+ "<div style=\"height: 1.5em; width: " + pixels + "px; background-color: " + color + ";\"></div>"
+ "<div style=\"position: absolute; text-align: center; padding-top: .25em; width: " + width + "px; top: 0; left: 0\">" + percent + "%</div>"
+ "</div>";
return diskcode;
}
</script>
</head>
<body>
<div class="header">
<span class="headerlogo">Rpi-1 Server</span>
<input class="menu-btn" type="checkbox" id="menu-btn" />
<label class="menu-icon" for="menu-btn"><span class="navicon"></span></label>
<ul class="menu">
<li><a href="/">Home</a></li>
</ul>
</div>
<div class="content">
<div class="card">
<div class="primary-title">
<div class="primary-text">UPS Status</div>
</div>
<div class="supporting-text">
<?php
/**
 * APC Access Battery Backup Status to HTML Table
 *
 * This script retrieves APC UPS (Uninterruptible Power Supply) status information using the apcaccess command.
 * It presents the output in an HTML table, providing a concise description for each status code and its corresponding value.
 * The script uses a predefined dictionary to map APC UPS status codes to shorter, more readable descriptions.
 *
 * Usage: Run this script in a PHP-enabled web server environment.
 */

$status_codes = array(
    'DATE' => 'Last update',
    'HOSTNAME' => 'Host',
    'VERSION' => 'Version info',
    'UPSNAME' => 'UPS name',
    'CABLE' => 'Cable type',
    'MODEL' => 'UPS model',
    'UPSMODE' => 'UPS mode',
    'STARTTIME' => 'Start time',
    'STATUS' => 'UPS status',
    'MASTERUPD' => 'Master update',
    'ENDAPC' => 'Status time',
    'LINEV' => 'Input voltage',
    'LOADPCT' => 'Load %',
    'BCHARGE' => 'Battery %',
    'TIMELEFT' => 'Runtime left',
    'MBATTCHG' => 'Min charge%',
    'MINTIMEL' => 'Min runtime',
    'MAXTIME' => 'Max runtime',
    'MAXLINEV' => 'Max voltage',
    'MINLINEV' => 'Min voltage',
    'OUTPUTV' => 'Output voltage',
    'SENSE' => 'Sensitivity',
    'DWAKE' => 'Wake time',
    'DSHUTD' => 'Shutdown delay',
    'DLOWBATT' => 'Low signal',
    'LOTRANS' => 'Low switch',
    'HITRANS' => 'High switch',
    'RETPCT' => 'Restore %',
    'ITEMP' => 'Temperature',
    'ALARMDEL' => 'Alarm delay',
    'BATTV' => 'Battery voltage',
    'LINEFREQ' => 'Line frequency',
    'LASTXFER' => 'Last transfer',
    'NUMXFERS' => 'Transfer count',
    'XONBATT' => 'On battery',
    'TONBATT' => 'Battery time',
    'CUMONBATT' => 'Cumulative time',
    'XOFFBAT' => 'Off battery',
    'SELFTEST' => 'Self test',
    'STESTI' => 'Test interval',
    'STATFLAG' => 'Status flag',
    'DIPSW' => 'DIP settings',
    'REG1' => 'Fault 1',
    'REG2' => 'Fault 2',
    'REG3' => 'Fault 3',
    'MANDATE' => 'Manufacture date',
    'SERIALNO' => 'Serial number',
    'BATTDATE' => 'Battery date',
    'NOMOUTV' => 'Nominal output',
    'NOMBATTV' => 'Nominal battery',
    'EXTBATTS' => 'External batteries',
    'BADBATTS' => 'Bad batteries',
    'FIRMWARE' => 'Firmware version',
    'APCMODEL' => 'APC model',
    'NOMPOWER' => 'Nominal power',
    'HUMIDITY' => 'Humidity',
    'AMBTEMP' => 'Ambient temp',
    'LINEFAIL' => 'Line status',
    'BATTSTAT' => 'Battery status'
);

// get the output of apcaccess
$output = shell_exec('apcaccess');

// check if the output is empty or the command failed
if (empty($output)) {
    echo 'Error:<svg height="15" width="15" class="blinkingdot"><circle cx="10" cy="10" r="5" fill="#FF0000"></svg> The apcaccess command failed or returned no output. Please check if APC UPS is connected and apcaccess is installed and configured correctly.';
}

$lines = explode(PHP_EOL, $output);

// print out the start of the table
echo "<table>\n";

foreach ($lines as $line) {
    // split each line by colon to separate status code and value
    $parts = explode(':', $line, 2);

    if (count($parts) == 2) {
        $status_code = trim($parts[0]);
        $value = trim($parts[1]);

		if ($status_code == 'STATUS' && $value != 'ONLINE')
		{
			$value = $value . ' <svg height="15" width="15" class="blinkingdot"><circle cx="10" cy="10" r="5" fill="#FF0000"></svg>';
		}
		elseif ($status_code == 'STATUS' && $value == 'ONLINE')
		{
			$value = $value . ' <svg height="15" width="15"><circle cx="10" cy="10" r="5" fill="#00FF00"></svg>';
		}

        // check if the status code exists in our array
        if (isset($status_codes[$status_code])) {
            // print out the row of the table
            echo "<tr>\n";
            echo "<td>" . $status_codes[$status_code] . "</td>";
            echo "<td>" . $value . "</td>\n";
            echo "</tr>\n";
        }

        if ($status_code == 'LOADPCT')
		{
			$upsload = floatval($value);
			$upsload = $upsload / 100;

		}
		if ($status_code == 'NOMPOWER')
		{
			$upsnompower = floatval($value);
		}
		$watts = $upsnompower * $upsload;
    }
}

// print out the end of the table
echo "</table>";
?>
</div>
<hr>
<div class="actions">
<div class="cardfooter">Load: <?php echo $watts; ?> watts</div>
<div class="cardfooter float-right"></div>
</div>
</div>

<?php
$db = new PDO("sqlite:/var/www/html/db/EventLog.db");
$result = $db->query("SELECT rowid FROM EventTable");
$rows = $result->fetchAll();
$total_pages = count($rows);
$limit = 10;
$adjacents = 3;
if(isset($_GET['page']))
{
$page = $_GET['page'];
if(preg_match('/[^0-9]/i', $page))
{
echo "SQL Injection detected!";
exit();
}
}
if(isset($page))
$start = ($page - 1) * $limit; 			//first item to display on this page
else
$start = 0;
$i = 1;
//now output the data to a simple html table...
$result = $db->query("SELECT Title, Message, Date, IP, User, P FROM EventTable ORDER BY rowid DESC LIMIT '$start', '$limit'");

foreach($result as $row) {
if(isset($row['P']))
{
$priority = $row['P'];
if($priority <= 3)
{
	$priorityicon = '<svg fill="#3399ff" viewBox="0 0 16 16" style="vertical-align:middle;line-height:24px;width:22px;height:22px;"><path d="M8.982 1.566a1.13 1.13 0 0 0-1.96 0L.165 13.233c-.457.778.091 1.767.98 1.767h13.713c.889 0 1.438-.99.98-1.767zM8 5c.535 0 .954.462.9.995l-.35 3.507a.552.552 0 0 1-1.1 0L7.1 5.995A.905.905 0 0 1 8 5m.002 6a1 1 0 1 1 0 2 1 1 0 0 1 0-2"/></svg> ';
}
elseif($priority >= 4 && $priority <= 7)
{
	$priorityicon = '<svg fill="#FFA500" viewBox="0 0 16 16" style="vertical-align:middle;line-height:24px;width:22px;height:22px;"><path d="M8.982 1.566a1.13 1.13 0 0 0-1.96 0L.165 13.233c-.457.778.091 1.767.98 1.767h13.713c.889 0 1.438-.99.98-1.767zM8 5c.535 0 .954.462.9.995l-.35 3.507a.552.552 0 0 1-1.1 0L7.1 5.995A.905.905 0 0 1 8 5m.002 6a1 1 0 1 1 0 2 1 1 0 0 1 0-2"/></svg> ';
}
elseif($priority > 7)
{
	$priorityicon = '<svg fill="#FF0000" viewBox="0 0 16 16" style="vertical-align:middle;line-height:24px;width:22px;height:22px;"><path d="M8.982 1.566a1.13 1.13 0 0 0-1.96 0L.165 13.233c-.457.778.091 1.767.98 1.767h13.713c.889 0 1.438-.99.98-1.767zM8 5c.535 0 .954.462.9.995l-.35 3.507a.552.552 0 0 1-1.1 0L7.1 5.995A.905.905 0 0 1 8 5m.002 6a1 1 0 1 1 0 2 1 1 0 0 1 0-2"/></svg> ';
}
}
else
{
	$priorityicon = NULL;
	$priority = NULL;
}
$user = isset($row['User']) ? " / User: " . $row['User'] : NULL;
$priority = isset($priority) ? " / P: " . $priority : NULL;
echo "<div class=\"card\">
<div class=\"primary-title\">
<div class=\"primary-text\">" . $priorityicon . $row['Title'] . "</div>
</div>
<div class=\"supporting-text\">\n";
echo nl2br($row['Message'], false)."\n";
echo "</div>
<hr>
<div class=\"actions\">
<div class=\"cardfooter\">";
echo date('l, F d Y, h:i:s A', $row['Date']) . $priority . $user;
echo "</div>
<div class=\"cardfooter float-right\">";
echo "IP: " . $row['IP'];
echo "</div>
</div>
</div>\n";
}
echo "</div>";
// echo $result->fetchColumn(1);
// close the database connection
$db = NULL;
/*
	Plugin Name: *Digg Style Paginator
	Plugin URI: http://www.mis-algoritmos.com/2006/11/23/paginacion-al-estilo-digg-y-sabrosus/
	Description: Adds a <strong>digg style pagination</strong>.
	Version: 0.1 Beta
*/
function pagination($total_pages,$limit,$page,$file,$adjacents){
		if($page)
				$start = ($page - 1) * $limit; 			//first item to display on this page
			else
				$start = 0;								//if no page var is given, set start to 0

		/* Setup page vars for display. */
		if ($page == 0) $page = 1;					//if no page var is given, default to 1.
		$prev = $page - 1;							//anterior page is page - 1
		$siguiente = $page + 1;							//siguiente page is page + 1
		$lastpage = ceil($total_pages/$limit);		//lastpage is = total pages / items per page, rounded up.
		$lpm1 = $lastpage - 1;						//last page minus 1

		$link_previous = "&#x276E; Previous";
		$link_next = "Next &#x276F;";

		$p = false;
		if(strpos($file,"?")>0)
			$p = true;

		//ob_start();
		if($lastpage > 1){
				//anterior button
				if($page > 1)
								if($p)
									echo "<span class=\"pagination-prev\"><a href=\"$file$prev\" class=\"pagination-button left\">$link_previous</a></span>";
									else
									echo "<span class=\"pagination-prev\"><a href=\"$file$prev\" class=\"pagination-button left\">$link_previous</a></span>";
					else
						echo "<span class=\"buttonDisabled leftDisabled\">$link_previous</span>";
				//pages
				if ($lastpage < 7 + ($adjacents * 2)){//not enough pages to bother breaking it up
						for ($counter = 1; $counter <= $lastpage; $counter++){
								if ($counter == $page)
										echo "<span class=\"pagination-button middleCurrent\">$counter</span>";
									else
												if($p)
												echo "<a href=\"$file$counter\" class=\"pagination-button middle\">$counter</a>";
												else
												echo "<a href=\"$file?page=$counter\" class=\"pagination-button middle\">$counter</a>";
							}
					}
				elseif($lastpage > 5 + ($adjacents * 2)){//enough pages to hide some
						//close to beginning; only hide later pages
						if($page < 1 + ($adjacents * 2)){
								for ($counter = 1; $counter < 4 + ($adjacents * 2); $counter++){
										if ($counter == $page)
												echo "<span class=\"pagination-button middleCurrent\">$counter</span>";
											else
														if($p)
														echo "<a href=\"$file$counter\" class=\"pagination-button middle\">$counter</a>";
														else
														echo "<a href=\"$file?page=$counter\" class=\"pagination-button middle\">$counter</a>";
									}
								echo "";
										if($p){
										echo "<a href=\"$file$lpm1\" class=\"pagination-button middle\">$lpm1</a>";
										echo "<a href=\"$file$lastpage\" class=\"pagination-button middle\">$lastpage</a>";
										}else{
										echo "<a href=\"$file?page=$lpm1\" class=\"pagination-button middle\">$lpm1</a>";
										echo "<a href=\"$file?page=$lastpage\" class=\"pagination-button middle\">$lastpage</a>";
										}

							}
						//in middle; hide some front and some back
						elseif($lastpage - ($adjacents * 2) > $page && $page > ($adjacents * 2)){
										if($p){
										echo "<a href=\"{$file}1\" class=\"pagination-button middle\">1</a>";
										echo "<a href=\"{$file}2\" class=\"pagination-button middle\">2</a>";
										}else{
										echo "<a href=\"$file?page=1\" class=\"pagination-button middle\">1</a>";
										echo "<a href=\"$file?page=2\" class=\"pagination-button middle\">2</a>";
										}
								echo "";
								for ($counter = $page - $adjacents; $counter <= $page + $adjacents; $counter++)
									if ($counter == $page)
											echo "<span class=\"pagination-button middleCurrent\">$counter</span>";
										else
													if($p)
													echo "<a href=\"$file$counter\" class=\"pagination-button middle\">$counter</a>";
													else
													echo "<a href=\"$file?page=$counter\" class=\"pagination-button middle\">$counter</a>";
								echo "";
										if($p){
										echo "<a href=\"$file$lpm1\" class=\"pagination-button middle\">$lpm1</a>";
										echo "<a href=\"$file$lastpage\" class=\"pagination-button middle\">$lastpage</a>";
										}else{
										echo "<a href=\"$file?page=$lpm1\" class=\"pagination-button middle\">$lpm1</a>";
										echo "<a href=\"$file?page=$lastpage\" class=\"pagination-button middle\">$lastpage</a>";
										}
							}
						//close to end; only hide early pages
						else{
										if($p){
										echo "<a href=\"{$file}1\" class=\"pagination-button middle\">1</a>";
										echo "<a href=\"{$file}2\" class=\"pagination-button middle\">2</a>";
										}else{
										echo "<a href=\"$file?page=1\" class=\"pagination-button middle\">1</a>";
										echo "<a href=\"$file?page=2\" class=\"pagination-button middle\">2</a>";
										}
								echo "";
								for ($counter = $lastpage - (2 + ($adjacents * 2)); $counter <= $lastpage; $counter++)
									if ($counter == $page)
											echo "<span class=\"pagination-button middleCurrent\">$counter</span>";
										else
													if($p)
													echo "<a href=\"$file$counter\" class=\"pagination-button middle\">$counter</a>";
													else
													echo "<a href=\"$file?page=$counter\" class=\"pagination-button middle\">$counter</a>";
							}
					}
				if ($page < $counter - 1)
								if($p)
								echo "<span class=\"pagination-next\"><a href=\"$file$siguiente\" class=\"pagination-button right\">$link_next</a></span>";
								else
								echo "<span class=\"pagination-next\"><a href=\"$file?page=$siguiente\" class=\"pagination-button rightDisabled\">$link_next</a></span>";
					else
						echo "<span class=\"buttonDisabled rightDisabled pagination-next\">$link_next</span>";
			}
	}
// Pagination Ends
if(!isset($page))
$page=1;
echo "\n</div>\n";
echo "\n<nav class=\"pagination_keyboard\">\n";
echo "\n<div class=\"pagination_style\">\n";
echo pagination($total_pages,$limit,$page,$_SERVER["PHP_SELF"]."?page=",$adjacents);
echo "\n</div>\n";
echo "\n</nav>";
?>

</div>
<div class="footer">
<div style="margin: 0 auto; padding:25px;">
<?php
echo 'Server time: '.date('Y-m-d h:i:s A');
echo '<br>';
function secondsToHumanTime(int $seconds, array $filter = []): string
{
	$intervalDefinitions = [
		'year'   => ['interval' => 31536000, 'labels' => ['year', 'years']],
		'month'  => ['interval' => 2592000, 'labels' => ['month', 'months']],
		'week'   => ['interval' => 604800, 'labels' => ['week', 'weeks']],
		'day'    => ['interval' => 86400, 'labels' => ['day', 'days']],
		'hour'   => ['interval' => 3600, 'labels' => ['hour', 'hours']],
		'minute' => ['interval' => 60, 'labels' => ['minute','minutes']],
		'second' => ['interval' => 1, 'labels' => ['second','seconds']],
	];

	$filteredIntervalDefinitions = array_column($filter ? array_intersect_key($intervalDefinitions, array_flip($filter)) : $intervalDefinitions, 'labels', 'interval');

	$intervals = [];
	foreach ($filteredIntervalDefinitions as $numerator => $labels) {
		if($counter = intdiv($seconds, $numerator)) {
			$intervals[] = $counter . ' ' . ($labels[(int)((bool)($counter - 1))] ?? '');
			$seconds -= ($counter * $numerator);
		}
	}
	return implode(' ', $intervals);
}
$str   = shell_exec("cut -d. -f1 /proc/uptime");
$num   = floatval($str);
echo 'Uptime: ' . secondsToHumanTime($num, ['year', 'month', 'day', 'hour', 'minute']);
?>
</div>
<div style="margin: 0 auto; display:inline-block; font-size: 75%">
RAM
<div style="font-family: Arial; font-size: 0.875em; color: #000">
<span id="rambar"></span>
</div>
<span style='float: left;'><span id="serverresponse"></span> of <span id="ramtotal"></span> used</span>
<br><br>
CPU
<div style="font-family: Arial; font-size: 0.875em; color: #000">
<span id="cpubar"></span>
</div>
<br>
DISK
<div style="font-family: Arial; font-size: 0.875em; color: #000">
<span id="diskbar"></span>
</div>
<span style='float: left;'><?php echo "$du of $dt used"; ?></span>
</div>
<div style="margin: 0 auto; padding:25px;">
<?php $totalTime = array_sum(explode(' ', microtime())) - $startTime;
$totalTime = round($totalTime, 2);
echo "Page generated in " . $totalTime . " seconds";
?>
</div>
</div>
<script>
keyboardPagination('.pagination_keyboard',
{
	prev: '.pagination-prev',
	next: '.pagination-next'
});
</script>
</body>
</html>