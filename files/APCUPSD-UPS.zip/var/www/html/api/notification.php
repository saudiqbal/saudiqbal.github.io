<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
function GlobalInputFilter($param)
{
	$custom_entities = array(
	'&' => '&amp;',
	';' => '&semi;',
	'!' => '&excl;',
	'"' => '&quot;',
	'#' => '&num;',
	'$' => '&dollar;',
	'%' => '&percnt;',
	"'" => '&apos;',
	'(' => '&lpar;',
	')' => '&rpar;',
	'*' => '&ast;',
	'+' => '&plus;',
	',' => '&comma;',
	'/' => '&sol;',
	':' => '&colon;',
	'<' => '&lt;',
	'=' => '&equals;',
	'>' => '&gt;',
	'?' => '&quest;',
	'@' => '&commat;',
	'[' => '&lbrack;',
	'\\' => '&bsol;',
	']' => '&rsqb;',
	'^' => '&Hat;',
	'_' => '&lowbar;',
	'`' => '&grave;',
	'{' => '&lbrace;',
	'|' => '&vert;',
	'}' => '&rcub;',
	'§' => '&sect;',
	'©' => '&copy;',
	'¶' => '&para;',
	'-' => '&hyphen;',
	'~' => '&tilde;'
	);
	$param = strtr($param, $custom_entities);
	$normal_characters = 'a-zA-Z0-9\s`~!@#$\€\£\¥%^&*()_+-={}|:;<>?,.\/\"\'\\\[\]';
	$param = preg_replace("/[^$normal_characters]/", '', $param);
	return $param;
}

$token = $_GET['token'] ?? NULL;
$authentication_status = false;
$authentication_users=[
'yourpassword' => 'localhost'
];
foreach ($authentication_users as $key => $keyvalue) {
$authentication_status = ($key == $token) ? true : false;
if($authentication_status) break;
}
if(!$authentication_status) {
	http_response_code(401);
	echo 'badauth';
	exit;
}
else
{
$notificationtype = isset($_GET['target']) ? GlobalInputFilter($_GET['target']) : '';

$EventLogNotification = true;

$date = time();
$ip = $_SERVER['REMOTE_ADDR'];

if(empty($_GET['title']))
{
	echo 'Error: Empty title';
	exit;
}
if(empty($_GET['message']))
{
	echo 'Error: Empty message';
	exit;
}

$title = isset($_GET['title']) ? GlobalInputFilter($_GET['title']) : NULL;
$message = isset($_GET['message']) ? GlobalInputFilter($_GET['message']) : NULL;
$priority = isset($_GET['priority']) && preg_match('/^[0-9]+$/', $_GET['priority']) ? $_GET['priority'] : NULL;

// Event Log
if ($EventLogNotification)
{
	$dbEventLog = new PDO('sqlite:/var/www/html/db/EventLog.db');
	$dbEventLog->setAttribute(PDO::ATTR_EMULATE_PREPARES, false);
	$dbEventLog->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
	$stmt = $dbEventLog->prepare('INSERT INTO EventTable (Title, Message, DATE, IP, User, P) VALUES (:Title , :Message, :Date, :IP, :User, :Priority)');
	$stmt->bindValue(':Title', $title);
	$stmt->bindValue(':Message', $message);
	$stmt->bindValue(':Date', $date);
	$stmt->bindValue(':IP', $ip);
	$stmt->bindValue(':User', $keyvalue);
	$stmt->bindValue(':Priority', $priority);
	$stmt->execute();
	$status = true;
}

echo ($status) ? 'OK' : 'ERROR';
}
?>