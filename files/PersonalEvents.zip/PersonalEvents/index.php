<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Calendar Plan - Tasks Events App  #DailyPractice</title>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta http-equiv="X-UA-Compatible" content="ie=edge">
<link rel="stylesheet" href="./style.css">
<script src="js/keyboard-navigation.js"></script>
</head>
<body>
<div class="mobile-wrapper">
<!--======= Header =======-->
<header class="header">
<div class="container">
<span><a href="./" style="text-decoration:none;color:#555;">Personal Events</a></span>
</div>
</header>
<!--======= Today =======-->
<section class="today-box" id="today-box">
	<span class="breadcrumb">Today</span>
	<h3 class="date-title"><span id="current-date"></span></h3>
	<a href="add.php"><div class="plus-icon"><i>+</i></div></a>
</section>
<!--======= Upcoming Events =======-->
<section class="upcoming-events">
<div class="container">
<h3>Lastest Events</h3>
<div class="events-wrapper">
<?php
if(isset($_GET['eventid']))
{
$eventid = $_GET['eventid'];
if(preg_match('/[^0-9]/', $eventid))
{
exit;
}
$page = $eventid;
}
$db = new PDO("sqlite:db/PersonalEvents.db");
$result = $db->query("SELECT rowid FROM PersonalEvents");
$rows = $result->fetchAll();
$total_pages = count($rows);
$limit = 10;
$adjacents = 3;
if(isset($_GET['page']))
{
$page = $_GET['page'];
if(preg_match('/[^0-9]/i', $page))
{
echo "SQL Injection detected!";
exit();
}
}
if(isset($page))
$start = ($page - 1) * $limit; 			//first item to display on this page
else
$start = 0;

$result = $db->query("SELECT rowid, TimeStamp, EVENT FROM PersonalEvents ORDER BY TimeStamp DESC, rowid DESC LIMIT '$start', '$limit'");

$i = 1;
foreach($result as $row)
{
echo '	<div class="event">' . "\xA";
echo '		<i class="ion ion-ios-flame hot"></i>' . "\xA";
echo '		<h4 class="event__point">'.$row['TimeStamp'].'</h4>' . "\xA";
echo '		<span class="event__duration"><a href=\'edit.php?eventedit='.$row['rowid'].'\' title="Edit" style="text-decoration:none;color:#5555ff;"><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-edit"><path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7"></path><path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z"></path></svg></a><span style="display: inline-block; width: 10px;"></span><a href=\'delete.php?eventdelete='.$row['rowid'].'\' onclick="javascript:return confirm(\'Delete permanently?\')" title="Delete" style="color:#FF0000;text-decoration:none;"><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M3 6h18"></path><path d="M19 6v14c0 1-1 2-2 2H7c-1 0-2-1-2-2V6"></path><path d="M8 6V4c0-1 1-2 2-2h4c1 0 2 1 2 2v2"></path></svg></a></span>' . "\xA";
echo '		<p class="event__description">'.nl2br($row['EVENT']).'</p>' . "\xA";
echo '	</div>' . "\xA";
}
$db = NULL;
// Pagination Starts
function pagination($total_pages,$limit,$page,$file,$adjacents){
		if($page)
				$start = ($page - 1) * $limit; 			//first item to display on this page
			else
				$start = 0;								//if no page var is given, set start to 0

		/* Setup page vars for display. */
		if ($page == 0) $page = 1;					//if no page var is given, default to 1.
		$prev = $page - 1;							//anterior page is page - 1
		$siguiente = $page + 1;							//siguiente page is page + 1
		$lastpage = ceil($total_pages/$limit);		//lastpage is = total pages / items per page, rounded up.
		$lpm1 = $lastpage - 1;						//last page minus 1
		$link_previous = "&#10094; Previous";
		$link_next = "Next &#10095;";

		$p = false;
		if(strpos($file,"?")>0)
			$p = true;

		//ob_start();
		if($lastpage > 1){
			echo "<nav class=\"pagination_keyboard\">\n";
			echo "<div class=\"pagination_style\">\n";
				//anterior button
				if($page > 1)
								if($p)
									echo "<span class=\"pagination-prev\"><a href=\"$file$prev\" class=\"pagination-button left\">$link_previous</a></span>";
									else
									echo "<span class=\"pagination-prev\"><a href=\"$file$prev\" class=\"pagination-button left\">$link_previous</a></span>";
					else
						echo "<span class=\"buttonDisabled leftDisabled\">$link_previous</span>";
				//pages
				if ($lastpage < 7 + ($adjacents * 2)){//not enough pages to bother breaking it up
						for ($counter = 1; $counter <= $lastpage; $counter++){
								if ($counter == $page)
										echo "<span class=\"pagination-button middleCurrent\">$counter</span>";
									else
												if($p)
												echo "<a href=\"$file$counter\" class=\"pagination-button middle\">$counter</a>";
												else
												echo "<a href=\"$file?page=$counter\" class=\"pagination-button middle\">$counter</a>";
							}
					}
				elseif($lastpage > 5 + ($adjacents * 2)){//enough pages to hide some
						//close to beginning; only hide later pages
						if($page < 1 + ($adjacents * 2)){
								for ($counter = 1; $counter < 4 + ($adjacents * 2); $counter++){
										if ($counter == $page)
												echo "<span class=\"pagination-button middleCurrent\">$counter</span>";
											else
														if($p)
														echo "<a href=\"$file$counter\" class=\"pagination-button middle\">$counter</a>";
														else
														echo "<a href=\"$file?page=$counter\" class=\"pagination-button middle\">$counter</a>";
									}
								echo "";
										if($p){
										echo "<a href=\"$file$lpm1\" class=\"pagination-button middle\">$lpm1</a>";
										echo "<a href=\"$file$lastpage\" class=\"pagination-button middle\">$lastpage</a>";
										}else{
										echo "<a href=\"$file?page=$lpm1\" class=\"pagination-button middle\">$lpm1</a>";
										echo "<a href=\"$file?page=$lastpage\" class=\"pagination-button middle\">$lastpage</a>";
										}

							}
						//in middle; hide some front and some back
						elseif($lastpage - ($adjacents * 2) > $page && $page > ($adjacents * 2)){
										if($p){
										echo "<a href=\"{$file}1\" class=\"pagination-button middle\">1</a>";
										echo "<a href=\"{$file}2\" class=\"pagination-button middle\">2</a>";
										}else{
										echo "<a href=\"$file?page=1\" class=\"pagination-button middle\">1</a>";
										echo "<a href=\"$file?page=2\" class=\"pagination-button middle\">2</a>";
										}
								echo "";
								for ($counter = $page - $adjacents; $counter <= $page + $adjacents; $counter++)
									if ($counter == $page)
											echo "<span class=\"pagination-button middleCurrent\">$counter</span>";
										else
													if($p)
													echo "<a href=\"$file$counter\" class=\"pagination-button middle\">$counter</a>";
													else
													echo "<a href=\"$file?page=$counter\" class=\"pagination-button middle\">$counter</a>";
								echo "";
										if($p){
										echo "<a href=\"$file$lpm1\" class=\"pagination-button middle\">$lpm1</a>";
										echo "<a href=\"$file$lastpage\" class=\"pagination-button middle\">$lastpage</a>";
										}else{
										echo "<a href=\"$file?page=$lpm1\" class=\"pagination-button middle\">$lpm1</a>";
										echo "<a href=\"$file?page=$lastpage\" class=\"pagination-button middle\">$lastpage</a>";
										}
							}
						//close to end; only hide early pages
						else{
										if($p){
										echo "<a href=\"{$file}1\" class=\"pagination-button middle\">1</a>";
										echo "<a href=\"{$file}2\" class=\"pagination-button middle\">2</a>";
										}else{
										echo "<a href=\"$file?page=1\" class=\"pagination-button middle\">1</a>";
										echo "<a href=\"$file?page=2\" class=\"pagination-button middle\">2</a>";
										}
								echo "";
								for ($counter = $lastpage - (2 + ($adjacents * 2)); $counter <= $lastpage; $counter++)
									if ($counter == $page)
											echo "<span class=\"pagination-button middleCurrent\">$counter</span>";
										else
													if($p)
													echo "<a href=\"$file$counter\" class=\"pagination-button middle\">$counter</a>";
													else
													echo "<a href=\"$file?page=$counter\" class=\"pagination-button middle\">$counter</a>";
							}
					}
				if ($page < $counter - 1)
								if($p)
								echo "<span class=\"pagination-next\"><a href=\"$file$siguiente\" class=\"pagination-button right\">$link_next</a></span>";
								else
								echo "<span class=\"pagination-next\"><a href=\"$file?page=$siguiente\" class=\"pagination-button rightDisabled\">$link_next</a></span>";
					else
						echo "<span class=\"buttonDisabled rightDisabled pagination-next\">$link_next</span>";

			echo "\n</div>\n";
			echo "</nav>\n";
			}
	}
// Pagination Ends
if(!isset($page))
$page=1;
echo pagination($total_pages,$limit,$page,$_SERVER["PHP_SELF"]."?eventid=",$adjacents);
?>
</div>
</div>
</section>
</div>
<script>
const date = new Date();
let day = date.getDate();
let month = date.toLocaleString('default', { month: 'short' });
let year = date.getFullYear();
let currentDate = `${month} ${day}, ${year}`;
document.getElementById("current-date").textContent = currentDate;
</script>
<script>
keyboardPagination('.pagination_keyboard',
{
prev: '.pagination-prev',
next: '.pagination-next'
});
</script>
<?php
include "toast-code.php";
?>
</body>
</html>