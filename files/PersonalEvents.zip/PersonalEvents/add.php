<?php
// process.php
$formerror = 0;
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['submit'])) {
$raw_date = $_POST['event_date'];
if (empty($raw_date)) {
$formerror = 1;
$msgcode[] = "7";
}
if (!preg_match("/^[0-9]{4}-(0[1-9]|1[0-2])-(0[1-9]|[1-2][0-9]|3[0-1])$/",$raw_date)) {
echo "<h3>Incorrect Date! $raw_date</h3>";
$formerror = 1;
$msgcode[] = "2";
}
$content = $_POST['content'];
if(empty($content))
{
$formerror = 1;
$msgcode[] = "7";
}
if (strlen($content) < 5)
{
$formerror = 1;
$msgcode[] = "13";
}
elseif(strlen($content) > 1000)
{
$formerror = 1;
$msgcode[] = "14";
}
if(isset($msgcode) && in_array('9', $msgcode) && in_array('7', $msgcode))
{
	$msgcode = [];
	$msgcode[] = "7";
}
elseif(isset($msgcode) && in_array('7', $msgcode) && in_array('13', $msgcode))
{
	$msgcode = [];
	$msgcode[] = "7";
}
function GlobalInputFilter($param)
{
	$custom_entities = array(
	'&' => '&amp;',
	';' => '&semi;',
	'!' => '&excl;',
	'"' => '&quot;',
	'#' => '&num;',
	'$' => '&dollar;',
	'%' => '&percnt;',
	"'" => '&apos;',
	'(' => '&lpar;',
	')' => '&rpar;',
	'*' => '&ast;',
	'+' => '&plus;',
	',' => '&comma;',
	'/' => '&sol;',
	':' => '&colon;',
	'<' => '&lt;',
	'=' => '&equals;',
	'>' => '&gt;',
	'?' => '&quest;',
	'@' => '&commat;',
	'[' => '&lbrack;',
	'\\' => '&bsol;',
	']' => '&rsqb;',
	'^' => '&Hat;',
	'_' => '&lowbar;',
	'`' => '&grave;',
	'{' => '&lbrace;',
	'|' => '&vert;',
	'}' => '&rcub;',
	'§' => '&sect;',
	'©' => '&copy;',
	'¶' => '&para;',
	'~' => '&tilde;'
	);
	$param = strtr($param, $custom_entities);
	$normal_characters = 'a-zA-Z0-9\s`~!@#$\€\£\¥%^&*()_+-={}|:;<>?,.\/\"\'\\\[\]';
	$param = preg_replace("/[^$normal_characters]/", '', $param);
	return $param;
}
$content = GlobalInputFilter($content);
}
else
{
	$formerror = 1;
}
if ($formerror == 0){
$db = new PDO('sqlite:db/PersonalEvents.db');
$db->setAttribute(PDO::ATTR_EMULATE_PREPARES, false);
$db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
$stmt = $db->prepare("INSERT INTO PersonalEvents (TimeStamp, EVENT) VALUES (:TimeStamp ,:Content)");
$stmt->bindValue(':TimeStamp', $raw_date);
$stmt->bindValue(':Content', $content);
$stmt->execute();
header("Location: index.php?status=15");
exit;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Calendar Plan - Tasks Events App  #DailyPractice</title>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta http-equiv="X-UA-Compatible" content="ie=edge">
<link rel="stylesheet" href="./style.css">
</head>
<body>
<div class="mobile-wrapper">
<!--======= Header =======-->
<header class="header">
<div class="container">
<span><a href="./" style="text-decoration:none;color:#555;">Personal Events</a></span>
</div>
</header>
<!--======= Today =======-->
<section class="today-box" id="today-box">
	<span class="breadcrumb">Today</span>
	<h3 class="date-title"><span id="current-date"></span></h3>
	<a href="add.php"><div class="plus-icon"><i>+</i></div></a>
</section>
<!--======= Upcoming Events =======-->
<section class="upcoming-events">
<div class="container">
<h3>Add new event</h3>
<div class="events-wrapper">
<form action="add.php" method="POST">
<label for="event_date">Choose a Date:</label>
<input type="date" id="event_date" name="event_date" required>
<script>
document.getElementById('event_date').valueAsDate = new Date();
//document.getElementById('event_date').valueAsDate = new Date(Date.UTC(2025, 11, 17));
</script>
<br><br>
<textarea rows="15" id="textbox" name="content" maxlength="1000" autofocus><?php if (isset($_POST['submit'])){
echo $_POST['content'];
} ?></textarea>
<br><br>
<div style="text-align:left; margin-top: 20px;">
<input type="submit" name="submit" id="submit" tabindex="4" value="Submit" class="btnlt">
<div class="dropdown">
<button class="btnrt" style="border-left:1px solid #0053a6;" onclick="return false;">
<svg width="8" height="8" viewBox="0 0 24 24"><path fill="#fff" d="M12 21l-12-18h24z"></svg>
<i class="fa fa-caret-down"></i>
</button>
<div class="dropdown-content">
<a href="./">Cancel</a>
</div>
</div>
</div>
</form>
</div>
</div>
</section>
</div>
<script>
const date = new Date();
let day = date.getDate();
let month = date.toLocaleString('default', { month: 'short' });
let year = date.getFullYear();
let currentDate = `${month} ${day}, ${year}`;
document.getElementById("current-date").textContent = currentDate;
</script>
<?php
include "toast-code.php";
?>
</body>
</html>