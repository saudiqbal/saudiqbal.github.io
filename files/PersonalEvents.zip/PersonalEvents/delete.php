<?php
$formerror = 0;
if ($_SERVER["REQUEST_METHOD"] == "GET" && isset($_GET['eventdelete'])) {
$eventdelete = $_GET['eventdelete'];
if (preg_match('/[^0-9]/i',$eventdelete)) {
echo "<h3>Invalid Event ID</h3>";
$formerror = 1;
$msgcode[] = "2";
}
}
if ($formerror == 0){
$db = new PDO('sqlite:db/PersonalEvents.db');
$db->setAttribute(PDO::ATTR_EMULATE_PREPARES, false);
$db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
$stmt = $db->prepare("DELETE FROM PersonalEvents WHERE rowid = :RowID");
$stmt->bindParam(':RowID', $eventdelete);
$stmt->execute();
header("Location: index.php?status=16");
exit;
}
?>