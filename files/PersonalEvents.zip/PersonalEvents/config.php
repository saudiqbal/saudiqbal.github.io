<?php
// Name of your Notebook
$Title='Personal Tasks Events';
// SQLite Database file name
$db_filename = 'db/PersonalEvents.db';
?>