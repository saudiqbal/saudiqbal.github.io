<?php
if (isset($_GET['delete']))
{
$delete = $_GET['delete'];
if($delete == "true")
{
unlink("setup.php");
echo "file deleted!";
exit();
}
}
echo "<a href=\"setup.php?delete=true\">Delete this file</a><br><br>";

if (isset($_GET['setup']))
{
$setup = $_GET['setup'];
if($setup == "true")
{
  try
  {
    //open the database
    $db = new PDO('sqlite:db/PersonalEvents.db');

    //create the database
    $db->exec("CREATE TABLE PersonalEvents (TimeStamp TEXT NOT NULL, EVENT TEXT NOT NULL)");
	echo "Database and Table created sucessfully.<br>";
	
	// for ($i = 1; $i <= 25; $i++)
	// {
	// $db->exec("INSERT INTO Contents (Id, Content, S) VALUES ('$i', '', '')");
	// }
	echo "Values inserted into the database.<br>";
	
    // close the database connection
    $db = NULL;
	
  }
  catch(PDOException $e)
  {
    print 'Exception : '.$e->getMessage();
  }
exit();
}
}
echo "<a href=\"setup.php?setup=true\">Start the setup</a><br><br>";
?>